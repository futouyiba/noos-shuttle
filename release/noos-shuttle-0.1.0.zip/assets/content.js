function v(e,t=new Date){const n=t.toISOString().slice(0,10),o=S(e)||"noos-thread";return`${n}-${o}.md`}function T(e,t=new Date){return`.noos/handoffs/active/${v(e,t)}`}function S(e){return e.normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").replace(/-{2,}/g,"-").slice(0,80)}function N(e=globalThis.location?.href??"",t="zh"){const n=new Date().toISOString().slice(0,10),o=T("example-thread-title",new Date(`${n}T00:00:00.000Z`));return t==="zh"?`请基于当前对话生成一份 NOOS Thread / 交接稿。

这份交接稿的用途，是把当前讨论交给 Codex、Claude Code、OpenCode 等编码代理继续执行。

只输出一个 markdown 交接块。不要在交接块外写解释、寒暄或补充说明。

交接稿必须被以下精确标记包裹：

<!-- NOOS:THREAD:BEGIN -->
...
<!-- NOOS:THREAD:END -->

使用 YAML frontmatter，字段保持英文键名：
- type: noos_thread
- version: 0.1
- source_app: chatgpt
- source_url: ${e}
- target_agent: codex
- status: active
- created_at: ${n}
- title
- tags
- preferred_path，路径格式参考：${o}

正文请使用中文，并包含以下章节：
# 交接：<标题>

## 意图
## 背景摘要
## 任务
## 约束
## 验收标准
## 建议给下一位代理的指令
## 未决问题
## 相关文件或链接

要求：内容简洁但完整，让下一位代理不必重读整段对话，也能理解背景、任务、约束和验收标准。`:`Please generate a NOOS Thread / Handoff based on the current conversation.

The purpose is to hand off this discussion to a coding agent such as Codex, Claude Code, or OpenCode.

Output only one markdown handoff block. Do not include any explanation outside the block.

The handoff must be wrapped by these exact markers:

<!-- NOOS:THREAD:BEGIN -->
...
<!-- NOOS:THREAD:END -->

Use YAML frontmatter with:
- type: noos_thread
- version: 0.1
- source_app: chatgpt
- source_url: ${e}
- target_agent: codex
- status: active
- created_at: ${n}
- title
- tags
- preferred_path, using this pattern: ${o}

The body must include:
# Thread: <title>

## Intent
## Context Summary
## Task
## Constraints
## Acceptance Criteria
## Suggested Next-Agent Instructions
## Open Questions
## Relevant Files or Links

Make it concise but complete enough for another agent to continue the work without rereading the full conversation.`}function $(e){const t=e.replace(/^\s*<!-- NOOS:THREAD:BEGIN -->\s*/,"").replace(/\s*<!-- NOOS:THREAD:END -->\s*$/,"").trim();if(!t.startsWith("---"))return{bodyMarkdown:t,warnings:["Missing YAML frontmatter."]};const n=t.indexOf(`
---`,3);if(n===-1)return{bodyMarkdown:t,warnings:["YAML frontmatter is not closed."]};const o=t.slice(3,n).trim(),a=t.slice(n+4).trim();return{frontmatter:C(o),bodyMarkdown:a,warnings:[]}}function C(e){const t={};for(const n of e.split(/\r?\n/)){const o=n.match(/^([A-Za-z0-9_]+):\s*(.*)$/);if(!o)continue;const[,a,s]=o,i=s.trim();i.startsWith("[")&&i.endsWith("]")?t[a]=i.slice(1,-1).split(",").map(c=>g(c.trim())).filter(Boolean):t[a]=g(i)}return t}function g(e){return e.replace(/^["']|["']$/g,"")}const b="<!-- NOOS:THREAD:BEGIN -->",m="<!-- NOOS:THREAD:END -->",E=[["## Intent","## 意图"],["## Context Summary","## 背景摘要"],["## Task","## 任务"],["## Constraints","## 约束"],["## Acceptance Criteria","## 验收标准"],["## Suggested Next-Agent Instructions","## 建议给下一位代理的指令"],["## Open Questions","## 未决问题"]];function D(e,t=new Date().toISOString()){const n=[],o=[];let a=0;for(;a<e.length;){const s=e.indexOf(b,a);if(s===-1)break;const i=e.indexOf(m,s+b.length);if(i===-1){o.push("Found a NOOS begin marker without a matching end marker.");break}const c=i+m.length,h=e.slice(s,c).trim(),l=$(h),O=I(l.frontmatter?.title,l.bodyMarkdown),k=H(l.frontmatter,l.bodyMarkdown,l.warnings);n.push({id:`${t}-${s}`,title:O,rawMarkdown:h,frontmatter:l.frontmatter,bodyMarkdown:l.bodyMarkdown,markerRange:{begin:s,end:c},detectedAt:t,warnings:k}),a=c}return{threads:n,errors:o}}function I(e,t){if(e)return e;const n=t.match(/^#\s+Thread:\s*(.+)$/im);if(n?.[1])return n[1].trim();const o=t.match(/^#\s+交接[：:]\s*(.+)$/im);return o?.[1]?o[1].trim():"Untitled NOOS Thread"}function H(e,t,n){const o=[...n];e?.type!=="noos_thread"&&o.push("Frontmatter should include type: noos_thread."),e?.version!=="0.1"&&o.push("Frontmatter should include version: 0.1."),!e?.title&&!/^#\s+Thread:\s*.+$/im.test(t)&&o.push("Thread title was not found.");for(const a of E)a.some(s=>t.includes(s))||o.push(`Missing required section: ${a.join(" / ")}.`);return o}const p={en:{localeName:"English",ready:"Ready to package this conversation.",close:"Close",draftHandoff:"Draft Handoff",collectHandoff:"Collect Handoff",copy:"Copy",download:"Download",settings:"Settings",language:"Language",noCapturedHandoff:"No captured handoff yet.",detectedHandoffs:"Detected Handoffs",warnings:"Warnings",untitledThread:"Untitled NOOS Thread",githubPlaceholder:"Placeholder adapter",promptInserted:"Prompt inserted. Review and send in ChatGPT.",inputNotFound:"Chat input box not found. The page layout may have changed.",noThreadDetected:"No NOOS Thread detected. Try Draft Handoff first.",chooseDetected:e=>`Detected ${e} handoffs. Choose one to deliver.`,captured:"Handoff collected.",capturedWithWarnings:"Collected with validation warnings.",captureBeforeDelivery:"Collect a NOOS Handoff before delivery.",copyFinished:"Copy finished.",downloadFinished:"Download finished.",githubUnavailable:"GitHub save unavailable."},zh:{localeName:"中文",ready:"可以把这段对话打包成交接稿。",close:"关闭",draftHandoff:"生成交接稿",collectHandoff:"收取交接稿",copy:"复制",download:"下载",settings:"设置",language:"语言",noCapturedHandoff:"还没有收取交接稿。",detectedHandoffs:"检测到的交接稿",warnings:"校验提醒",untitledThread:"未命名 NOOS 交接稿",githubPlaceholder:"GitHub 适配器占位",promptInserted:"提示词已写入。请在 ChatGPT 中检查后发送。",inputNotFound:"没有找到 ChatGPT 输入框。页面结构可能已经变化。",noThreadDetected:"没有检测到 NOOS 交接稿。可以先生成交接稿。",chooseDetected:e=>`检测到 ${e} 份交接稿。请选择要交付的一份。`,captured:"交接稿已收取。",capturedWithWarnings:"已收取，但存在校验提醒。",captureBeforeDelivery:"请先收取 NOOS 交接稿，再进行交付。",copyFinished:"复制完成。",downloadFinished:"下载完成。",githubUnavailable:"GitHub 保存暂不可用。"}};function M(e=navigator.language){return e.toLowerCase().startsWith("zh")?"zh":"en"}function x(){const e=window.localStorage.getItem("noos-shuttle-locale");return e==="en"||e==="zh"?e:M()}function _(e){window.localStorage.setItem("noos-shuttle-locale",e)}class A{id="clipboard";name="Clipboard";async saveThread(t,n){try{return await navigator.clipboard.writeText(t.rawMarkdown),{ok:!0,adapterId:this.id,location:"clipboard",message:"Copied to clipboard."}}catch(o){return{ok:!1,adapterId:this.id,errorCode:"clipboard_failed",message:o instanceof Error?o.message:"Clipboard write failed."}}}}class R{id="download";name="Markdown Download";async saveThread(t,n){const o=n?.filename??"noos-thread.md",a=new Blob([t.rawMarkdown],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(a);try{const i=document.createElement("a");return i.href=s,i.download=o,i.rel="noopener",i.click(),{ok:!0,adapterId:this.id,location:o,message:`Downloaded ${o}.`}}catch(i){return{ok:!1,adapterId:this.id,errorCode:"download_failed",message:i instanceof Error?i.message:"Download failed."}}finally{URL.revokeObjectURL(s)}}}class F{id="github";name="GitHub";async saveThread(t,n){return{ok:!1,adapterId:this.id,errorCode:"not_implemented",message:"GitHub delivery is planned after copy/download are stable."}}}const L=["textarea","div[contenteditable='true'][data-lexical-editor='true']","div[contenteditable='true']","[role='textbox']"];function G(){const e=document.querySelector("main");return U(e??document.body).trim()}function P(e){const t=z();return t?(t.focus(),t instanceof HTMLTextAreaElement?(t.value=e,t.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:e})),!0):(t.textContent=e,t.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:e})),!0)):!1}function z(){for(const e of L){const n=Array.from(document.querySelectorAll(e)).find(o=>B(o)&&!o.closest("[aria-hidden='true']"));if(n)return n}return null}function B(e){const t=e.getBoundingClientRect(),n=window.getComputedStyle(e);return t.width>0&&t.height>0&&n.visibility!=="hidden"&&n.display!=="none"}function U(e){const t=[],n=document.createTreeWalker(e,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_COMMENT);for(;n.nextNode();){const o=n.currentNode;if(W(o))continue;if(o.nodeType===Node.COMMENT_NODE){t.push(`<!-- ${o.nodeValue?.trim()??""} -->`);continue}const a=o.nodeValue?.trim();a&&t.push(a)}return t.join(`
`)}function W(e){const t=e.parentElement;return t?!!t.closest(["textarea","input","form","[contenteditable='true']","[role='textbox']","#noos-shuttle-root"].join(",")):!1}const j=":host{all:initial;color-scheme:light;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}*{box-sizing:border-box}.shuttle{position:fixed;z-index:2147483647;right:18px;bottom:84px;color:#17201a}.fab{width:44px;height:44px;border:0;border-radius:999px;background:#193b2d;color:#f6fff9;box-shadow:0 8px 22px #10181438;cursor:pointer;font:700 13px/1 system-ui,sans-serif}.fab--captured,.fab--saved{background:#1d6b4f}.fab--warning,.fab--needs-choice{background:#8b5a11}.fab--error{background:#9b2727}.popover{position:absolute;right:0;bottom:54px;width:min(380px,calc(100vw - 28px));max-height:min(640px,calc(100vh - 120px));overflow:auto;border:1px solid rgba(23,32,26,.12);border-radius:8px;background:#fbfdfb;box-shadow:0 18px 48px #10181438}.header{display:flex;gap:12px;align-items:flex-start;justify-content:space-between;padding:14px;border-bottom:1px solid rgba(23,32,26,.1)}.header strong,.preview-title,.warnings strong{display:block;font:700 13px/1.25 system-ui,sans-serif}.header span,.github-note span,.empty{display:block;margin-top:5px;color:#5c665f;font:400 12px/1.35 system-ui,sans-serif}.icon-button{width:26px;height:26px;border:1px solid rgba(23,32,26,.12);border-radius:6px;background:#fff;color:#344039;cursor:pointer}.actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:12px 14px}.actions button,.github-note button{min-height:34px;border:1px solid rgba(23,32,26,.14);border-radius:6px;background:#fff;color:#17201a;cursor:pointer;font:600 12px/1.2 system-ui,sans-serif}.actions button:hover:not(:disabled),.github-note button:hover:not(:disabled),.icon-button:hover{border-color:#1d6b4f73;background:#f2faf6}button:disabled{cursor:not-allowed;opacity:.46}.empty{padding:4px 14px 14px}.field{display:grid;gap:6px;padding:0 14px 12px;color:#344039;font:600 12px/1.3 system-ui,sans-serif}.field select{width:100%;min-height:34px;border:1px solid rgba(23,32,26,.14);border-radius:6px;background:#fff;color:#17201a}.preview{margin:0 14px 12px;border:1px solid rgba(23,32,26,.1);border-radius:8px;background:#fff}.preview-title{padding:10px 11px;border-bottom:1px solid rgba(23,32,26,.08)}.preview pre{max-height:230px;margin:0;overflow:auto;padding:11px;white-space:pre-wrap;word-break:break-word;color:#28332d;font:400 11px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}.warnings{margin:10px 11px 0;padding:9px;border:1px solid rgba(139,90,17,.24);border-radius:6px;background:#fff8ed;color:#5f3b06}.warnings ul{margin:6px 0 0;padding-left:18px;font:400 11px/1.35 system-ui,sans-serif}.github-note{display:flex;gap:10px;align-items:center;padding:0 14px 10px}.github-note button{min-width:88px}.settings{padding:0 14px 14px}.settings-toggle{width:100%;min-height:32px;border:1px solid rgba(23,32,26,.12);border-radius:6px;background:#f6f8f6;color:#344039;cursor:pointer;font:600 12px/1.2 system-ui,sans-serif}.settings-panel{display:grid;gap:8px;margin-top:8px;padding:10px;border:1px solid rgba(23,32,26,.1);border-radius:8px;background:#fff}.settings-label{color:#5c665f;font:600 12px/1.3 system-ui,sans-serif}.segmented{display:grid;grid-template-columns:1fr 1fr;gap:4px;padding:3px;border:1px solid rgba(23,32,26,.12);border-radius:7px;background:#f6f8f6}.segmented button{min-height:30px;border:0;border-radius:5px;background:transparent;color:#344039;cursor:pointer;font:700 12px/1.2 system-ui,sans-serif}.segmented button[aria-pressed=true]{background:#193b2d;color:#f6fff9}",q=new A,Y=new R,V=new F,r={open:!1,settingsOpen:!1,state:"idle",message:p[x()].ready,threads:[],selectedIndex:0,locale:x()};K();function K(){if(document.getElementById("noos-shuttle-root"))return;const e=document.createElement("div");e.id="noos-shuttle-root";const t=e.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=j,t.append(n);const o=document.createElement("div");o.className="shuttle",t.append(o),document.documentElement.append(e),d(o)}function d(e){const t=r.threads[r.selectedIndex],n=p[r.locale];e.innerHTML=`
    <button class="fab fab--${r.state}" type="button" aria-label="NOOS Shuttle">
      <span>NS</span>
    </button>
    ${r.open?`<section class="popover" aria-label="NOOS Shuttle">
            <header class="header">
              <div>
                <strong>NOOS Shuttle</strong>
                <span>${u(r.message)}</span>
              </div>
              <button class="icon-button" type="button" data-action="close" aria-label="${n.close}">x</button>
            </header>
            <div class="actions">
              <button type="button" data-action="generate">${n.draftHandoff}</button>
              <button type="button" data-action="capture">${n.collectHandoff}</button>
              <button type="button" data-action="copy" ${t?"":"disabled"}>${n.copy}</button>
              <button type="button" data-action="download" ${t?"":"disabled"}>${n.download}</button>
            </div>
            ${Q(t)}
            <div class="github-note">
              <button type="button" data-action="github" ${t?"":"disabled"}>GitHub</button>
              <span>${n.githubPlaceholder}</span>
            </div>
            <div class="settings">
              <button class="settings-toggle" type="button" data-action="settings">${n.settings}</button>
              ${r.settingsOpen?`<div class="settings-panel">
                      <div class="settings-label">${n.language}</div>
                      <div class="segmented" role="group" aria-label="${n.language}">
                        <button type="button" data-action="locale-zh" aria-pressed="${r.locale==="zh"}">中文</button>
                        <button type="button" data-action="locale-en" aria-pressed="${r.locale==="en"}">English</button>
                      </div>
                    </div>`:""}
            </div>
          </section>`:""}
  `,e.querySelector(".fab")?.addEventListener("click",()=>{r.open=!r.open,d(e)}),e.querySelectorAll("[data-action]").forEach(o=>{o.addEventListener("click",()=>w(o.dataset.action??"",e))}),e.querySelector("select[data-action='select-thread']")?.addEventListener("change",()=>{w("select-thread",e)})}function Q(e){const t=p[r.locale];if(r.threads.length===0)return`<div class="empty">${t.noCapturedHandoff}</div>`;const n=r.threads.length>1?`<label class="field">
          <span>${t.detectedHandoffs}</span>
          <select data-action="select-thread">
            ${r.threads.map((a,s)=>`<option value="${s}" ${s===r.selectedIndex?"selected":""}>${u(a.title)}</option>`).join("")}
          </select>
        </label>`:"",o=e?.warnings.length?`<div class="warnings">
        <strong>${t.warnings}</strong>
        <ul>${e.warnings.map(a=>`<li>${u(a)}</li>`).join("")}</ul>
      </div>`:"";return`
    ${n}
    <article class="preview">
      <div class="preview-title">${u(e?.title??t.untitledThread)}</div>
      ${o}
      <pre>${u(e?.rawMarkdown??"")}</pre>
    </article>
  `}async function w(e,t){const n=p[r.locale];if(e==="close"){r.open=!1,d(t);return}if(e==="select-thread"){const a=t.querySelector("select[data-action='select-thread']");r.selectedIndex=Number(a?.value??0),y(),d(t);return}if(e==="settings"){r.settingsOpen=!r.settingsOpen,d(t);return}if(e==="locale-zh"||e==="locale-en"){const a=e==="locale-zh"?"zh":"en";r.locale=a,_(a),r.message=p[a].ready,d(t);return}if(e==="generate"){const a=P(N(window.location.href,r.locale));r.state=a?"prompt-ready":"error",r.message=a?n.promptInserted:n.inputNotFound,d(t);return}if(e==="capture"){const a=D(G());r.threads=a.threads,r.selectedIndex=0,a.threads.length===0?(r.state="error",r.message=a.errors[0]??n.noThreadDetected):a.threads.length>1?(r.state="needs-choice",r.message=n.chooseDetected(a.threads.length)):(y(),r.message=a.threads[0].warnings.length>0?n.capturedWithWarnings:n.captured),d(t);return}const o=r.threads[r.selectedIndex];if(!o){r.state="error",r.message=n.captureBeforeDelivery,d(t);return}if(e==="copy"){const a=await q.saveThread(o);f(a.ok?n.copyFinished:a.message??n.copyFinished,a.ok),d(t);return}if(e==="download"){const a=v(o.title),s=await Y.saveThread(o,{filename:a});f(s.ok?n.downloadFinished:s.message??n.downloadFinished,s.ok),d(t);return}if(e==="github"){const a=await V.saveThread(o);f(a.message??n.githubUnavailable,a.ok),d(t)}}function y(){const e=r.threads[r.selectedIndex];r.state=e?.warnings.length?"warning":"captured"}function f(e,t){r.state=t?"saved":"error",r.message=e}function u(e){return e.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}
//# sourceMappingURL=content.js.map
