chrome.runtime.onInstalled.addListener(()=>{console.info("NOOS Shuttle installed.")});
//# sourceMappingURL=service-worker.js.map
